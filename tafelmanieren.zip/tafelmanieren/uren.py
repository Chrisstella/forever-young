#Print de hele uren van de dag.
# Voor de ochtend voeg je 'AM' toe. Voor de middag voeg je 'PM' toe

for o in range(1, 13):
    print(str(o)+ "am")

for m in range(1, 13):
    print(str(m)+ "pm")