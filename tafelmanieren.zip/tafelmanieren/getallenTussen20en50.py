#Chrisstella b
# Print alle even getallen tussen 20 en 50

for x in range(20, 51, 2):
    print(x)
