#Vanaf 30 terugtellen tot de raketlancering.
# Print elke tel en print de lancering.

for l in range(30, 0, -1):
    print(l)
    print("Lancering")